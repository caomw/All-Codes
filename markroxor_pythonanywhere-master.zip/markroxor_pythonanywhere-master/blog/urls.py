from django.conf.urls import include, url
from . import views

urlpatterns = [
    url(r'^$', views.index1, name='index1'),
    url(r'^projects/$', views.projects, name='projects'),
    url(r'^vision/$', views.vision, name='vision'),
    url(r'^about/$', views.about, name='about'),
    url(r'^index/$', views.index, name='index'),
    url(r'^home/$', views.home, name='home'),
    url(r'^generic/$', views.generic, name='generic'),
    url(r'^elements/$', views.elements, name='elements'),
    
    url(r'^blog/$', views.post_list, name='post_list'),
    url(r'^blog/(?P<pk>[0-9]+)/$', views.post_details, name='post_details'),
    url(r'^blog/new/$', views.post_new, name='post_new'),
    url(r'^blog/(?P<pk>[0-9]+)/edit/$', views.post_edit, name='post_edit'),
]